part3: placefinder silhouette spotdiff
