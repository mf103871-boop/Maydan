part2: blur zoom reveal guesscar
